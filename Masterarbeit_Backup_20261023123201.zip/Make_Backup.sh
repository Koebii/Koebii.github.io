i=$(date +%Y%m%d%H%M%S)
cd /Users/surfer/Library/CloudStorage/GoogleDrive-schmukijakob7@gmail.com/My\ Drive/01\ Uni/02\ Masterarbeit/
for j in */; do
zip -r ../Masterarbeit_Backup_"$i".zip "$j" -x "Literature*"
done
zip ../Masterarbeit_Backup_"$i".zip main.tex
zip ../Masterarbeit_Backup_"$i".zip Make_Backup.sh

