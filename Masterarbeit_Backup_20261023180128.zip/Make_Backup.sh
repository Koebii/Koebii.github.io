i=$(date +%Y%m%d%H%M%S)
backup_path=~/Downloads/
cd /Users/surfer/Library/CloudStorage/GoogleDrive-schmukijakob7@gmail.com/My\ Drive/01\ Uni/02\ Masterarbeit/
for j in */; do
zip -r "$backup_path"/Masterarbeit_Backup_"$i".zip "$j" -x "Literature*"
done
zip "$backup_path"/Masterarbeit_Backup_"$i".zip main.tex
zip "$backup_path"/Masterarbeit_Backup_"$i".zip Make_Backup.sh

